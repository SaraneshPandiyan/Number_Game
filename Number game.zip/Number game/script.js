const Number = document.getElementById("Guess");
const chance = document.getElementById("chance");

let TV = Math.floor(Math.random() * 100) + 1;

var Chances = 10;

function check(){
  const FN = parseInt(Number.value);
  if(FN === TV){
    window.location.href="won.html";
  }
  else{
    Chances--;
    chance.innerHTML= Chances;

    if(Chances===0){
      window.location.href="Failed.html";
    }

    else{
      if(FN>100){
        alert("Enter inbetween 1 to 100 Please...");
      }
      else if(FN>TV){
        alert(FN +" is Greater");
      }  
      else{
        alert(FN +" is Less");
      }
    }

  }
}

function restart(){
  window.location.href="index.html";
}